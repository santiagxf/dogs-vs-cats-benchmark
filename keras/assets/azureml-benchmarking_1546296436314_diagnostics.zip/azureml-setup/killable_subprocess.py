import subprocess
import sys
import time
import re

from threading import Thread


class SudoPermissionError(Exception):
    def __init__(self, innerException, message):
        super(SudoPermissionError, self).__init__(message)


def sudo_subprocess_call(command_args, print_command_args=False, *popen_args, **keyword_args):
    try:
        command_args = ["sudo"] + command_args
        return check_call(command_args + list(popen_args), print_command_args=print_command_args, **keyword_args)
    except subprocess.CalledProcessError as error:
        if error.returncode == 1:
            raise SudoPermissionError(
                error,
                error.message +
                'Sudo permission error: Azure ML Workbench requires passwordless sudo access,'
                ' see http://aka.ms/aml-ttysudoerror for instructions\n')
        else:
            raise error


def _reader_thread(file):
    for line in iter(file.readline, ""):
        if isinstance(line, bytes):
            try:
                # TODO Fix unicode string handling -- both decode and write can break when
                # line contains a character that isn't ASCII.
                decoded = line.decode()

                # Handle line rewrites through multiple carriage returns by just forwarding the last.
                stripped = decoded.rstrip("\r\n")
                last = stripped.split("\r")[-1]

                sys.stdout.write(last + "\n")
                sys.stdout.flush()
            except Exception:
                sys.stdout.write("Failed to handle log line that was not ASCII!\n")
                sys.stdout.flush()
                continue

        if not line:
            break


def subprocess_with_failure_recovery(popenargs, recoveryFunc):
    try:
        return check_call(popenargs)
    except subprocess.CalledProcessError as error:
        recoveryFunc(popenargs, error)
        raise error


def arguments_contain_sudo(*popenargs):
    if isinstance(popenargs[0], list):
        return popenargs[0][0] == "sudo"
    elif isinstance(popenargs[0], str):
        return popenargs[0].strip().startswith("sudo")
    else:
        raise TypeError("Wrong subprocess arguments format.")


# Returns pids of all descendents of root_process_pid. Doesn't include the root_process_pid.
# Returns None if root_process_pid < 0
def get_all_descendents_in_linux(root_process_pid):
    if root_process_pid < 0:
        return None

    # First we are getting all processes' pids and ppids. [0] is for reading the stdout
    # Setting universal_newlines=True for default string encoding.
    output = subprocess.check_output(['ps', '-eo', 'pid,ppid'], universal_newlines=True)
    all_process_list = output.splitlines()
    # Skipping the first line, as that is the column header, precisely, PID, PPID.
    all_process_list = all_process_list[1:]

    # A dictionary in which a key is a ppid, and the value is a list of children's pids.
    parent_to_child_dict = {}
    for item in all_process_list:
        # Removing leading, trailing and multiple spaces
        if len(item) > 0:
            item = re.sub(' +', ' ', item.strip())
            pid_string, ppid_string = item.split(" ")
            pid_int = int(pid_string)
            ppid_int = int(ppid_string)

            if ppid_int in parent_to_child_dict:
                parent_to_child_dict[ppid_int].append(pid_int)
            else:
                child_list = [pid_int]
                parent_to_child_dict[ppid_int] = child_list

    # Parent to child dictionary creation complete.

    # We just iteratively adding each pid's children to the output list.
    # We start from root_process_pid, and continue iteratively from there,
    # thereby performing a breadth-first traversal of a tree.

    all_descendant_list = []
    child_list = []

    # If root_process_pid is not in parent_to_child_dict, then it means
    # root_process_pid has no children
    if root_process_pid in parent_to_child_dict:
        child_list = parent_to_child_dict[root_process_pid]

    while len(child_list) > 0:
        # Adding the current chidren to the output list.
        all_descendant_list = all_descendant_list + child_list

        next_list = []
        for child_pid in child_list:
            if child_pid in parent_to_child_dict:
                next_list = next_list + parent_to_child_dict[child_pid]

        child_list = next_list

    # All descendants computation complete
    return all_descendant_list


# This function kills a process in linux and ignores
# the errors if the specified process has already died.
def kill_ignoring_dead_process_in_linux(kill_arguments):
    try:
        subprocess.check_call(kill_arguments)
    except OSError as e:
        if not e.strerror == "No such file or directory":
            raise e


# Kills the process tree for linux like environments.
# root_pid denotes the root process of the process tree.
# is_sudo is true if the root process was started using sudo, false otherwise.
def kill_process_tree_in_linux(root_pid, is_sudo):
    # Computing the list of all descendants.
    all_descendants = get_all_descendents_in_linux(root_pid)
    print("Killing parent process={} and all its descendant processes={}".format(root_pid, all_descendants))

    # All processes to kill, parent and all its descendants.
    all_processes = all_descendants + [root_pid]

    # The logic here handles the case if the parent process was not started using
    # sudo, but some of its children were started using sudo.
    for pid in all_processes:
        try:
            if is_sudo:
                kill_ignoring_dead_process_in_linux(["sudo", "kill", "-SIGKILL", str(pid)])
            else:
                # First we try without sudo. But, descendants could have been started with sudo
                # access, so if the non-sudo command raises an Error then we try with sudo.
                try:
                    kill_ignoring_dead_process_in_linux(["kill", "-SIGKILL", str(pid)])
                except BaseException:
                    kill_ignoring_dead_process_in_linux(["sudo", "kill", "-SIGKILL", str(pid)])
        except BaseException as e:
            # Catching all exceptions here in the case a process was not successfully killed.
            # Printing a warning and continuing with the killing of other processes.
            print("WARNING: Unable to kill process with pid={}. The exception is={}".format(pid, e))


def kill_process_tree_in_windows(root_pid):
    # This function kills the process tree in windows and ignores
    # the error if the specified process has already died.
    # Not sure if all processes in the process tree will be killed in case of an exception.
    try:
        subprocess.check_call(["TASKKILL", "/F", "/T", "/PID", str(root_pid)])
    except subprocess.CalledProcessError as e:
        # 128 is the taskkill return code in windows for "no such process",
        # which happens when a process has already died.
        if not e.returncode == 128:
            raise e


def check_call(*popenargs, **kwargs):
    if "print_command_args" in kwargs:
        if kwargs["print_command_args"]:
            print("Running: " + str(popenargs[0]))

        del kwargs["print_command_args"]

    interrupt_handler = kwargs.get("interrupt_handler")
    if interrupt_handler is not None:
        del kwargs["interrupt_handler"]

    if "stdout" not in kwargs:
        kwargs["stdout"] = subprocess.PIPE

    if "stderr" not in kwargs:
        kwargs["stderr"] = subprocess.PIPE

    process = None
    try:
        process = subprocess.Popen(*popenargs, **kwargs)

        stdout_thread = Thread(target=_reader_thread, args=[process.stdout])
        stdout_thread.daemon = True
        stdout_thread.start()

        stderr_thread = Thread(target=_reader_thread, args=[process.stderr])
        stderr_thread.daemon = True
        stderr_thread.start()

        # We do semi-busy waiting here, because the control script
        # may receive a signal from the interrupt_sender, and if
        # we wait, we will not wake up for the signal.
        while process.returncode is None:
            time.sleep(0.1)
            process.poll()

        stdout_thread.join()
        stderr_thread.join()

    # For Linuxy environments - a TypeError exception is thrown for KeyboardInterrupts.
    # Deduced this exception by verifying the output of type(exception).__name__
    except (KeyboardInterrupt, TypeError) as e:
        if interrupt_handler is not None:
            interrupt_handler()

        # This is because of a python bug in linux as reported
        # https://bugs.python.org/issue23395+&cd=3&hl=en&ct=clnk&gl=us.
        if isinstance(e, TypeError):
            raise KeyboardInterrupt("TypeError converted to KeyboardInterrupt. "
                                    "Original message={}".format(e))
        else:
            raise
    finally:
        if process is not None and process.returncode is None:
            if sys.platform == "win32":
                kill_process_tree_in_windows(process.pid)
            else:
                # Determining if the subprocess was started using sudo or not.
                is_sudo = arguments_contain_sudo(*popenargs)

                kill_process_tree_in_linux(process.pid, is_sudo)

    if process.returncode:
        cmd = kwargs.get("args")
        if cmd is None:
            cmd = popenargs[0]

        raise subprocess.CalledProcessError(process.returncode, cmd)
    return 0
