﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import os
import sys


try:
    # For Python 3.0 and later
    from urllib.request import urlopen, Request
    from urllib.error import URLError, HTTPError
except ImportError:
    # Fall back to Python 2's urllib2
    from urllib2 import urlopen, Request, URLError, HTTPError

# Cap the logging of upload errors to the first 10.
# This ensures if there are continual failures that the log does
# not continue to grow and will finish uploading
total_request_errors = 0


def should_print_this_error():
    global total_request_errors
    max_request_errors = 10
    total_request_errors += 1
    if total_request_errors == max_request_errors:
        print("Log uploader request error limit of {} reached. ".format(max_request_errors) +
              "Further errors will not be logged in order to prevent infinite log growth.")
    return total_request_errors <= max_request_errors


def try_request_with_retries(request, max_attempts, sleep_interval_sec, wait_handle):
    for i in range(0, max_attempts):
        if i > 0:
            wait_handle.wait(sleep_interval_sec * (2 ** (i - 1)))
            if wait_handle.isSet():
                return
        try:
            urlopen(request)
            return
        except URLError as ex:
            if should_print_this_error():
                print(ex.reason)
        except HTTPError as ex:
            if should_print_this_error():
                print(ex.code)
                print(ex.read())

            if i == max_attempts - 1:
                # We don't need to wait for the Retry-After, this is the last try anyway
                continue

            # If the error had a Retry-After, respect that
            if ex.headers and ex.headers['Retry-After']:
                hdr = ex.headers['Retry-After']
                if hdr.isdigit():
                    wait_handle.wait(int(hdr))
        except Exception as ex:
            if should_print_this_error():
                print(ex)


def tail_upload_artifact(path, artifact_name, wait_handle, error=None):
    def int_env_var_or_default(key, default):
        value = os.environ.get(key)
        return int(value) if value else default
    try:
        run_id = os.environ["AZUREML_RUN_ID"]
        service_endpoint = os.environ["AZUREML_SERVICE_ENDPOINT"]
        arm_scope = os.environ.get("AZUREML_WORKSPACE_SCOPE")
        account_token = os.environ.get("AZUREML_RUN_TOKEN")
        # default to a little less than 4 MB, the size limit for artifact chunks
        chunk_size_bytes = int_env_var_or_default("AZUREML_UPLOAD_CHUNK_SIZE_BYTES", 4 * 1000 * 1024)
        upload_max_attempts = int_env_var_or_default("AZUREML_UPLOAD_CHUNK_MAX_ATTEMPTS", 3)
        sleep_interval_sec = int_env_var_or_default("AZUREML_UPLOAD_SLEEP_INTERVAL_SEC", 2)

        secondary_instance = os.environ.get("AZUREML_SECONDARY_INSTANCE")
        secondary_multiplier = int_env_var_or_default("AZUREML_UPLOAD_SECONDARY_MULTIPLIER", 10)

        if secondary_instance:
            sleep_interval_sec *= secondary_multiplier

        print("Streaming log file " + artifact_name)

        last_uploaded_byte = 0
        chunk_index = 0
        with open(path, 'rb') as data:
            while True:
                data.seek(last_uploaded_byte)
                read_bytes = data.read(chunk_size_bytes)

                if read_bytes:
                    artifacts_url = "{0}/artifact/v1.0{1}/artifacts/content/ExperimentRun/{2}".format(
                        service_endpoint, arm_scope, run_id)
                    artifacts_url += "?&path={0}&index={1}".format(artifact_name, chunk_index)
                    request = Request(artifacts_url, data=read_bytes, headers={"Authorization": "Bearer {0}".format(
                        account_token), 'Content-Type': 'text/plain', 'Content-Length': '%d' % len(read_bytes)})
                    try_request_with_retries(request, upload_max_attempts, sleep_interval_sec, wait_handle)

                    chunk_index += 1
                    last_uploaded_byte += len(read_bytes)
                elif wait_handle.isSet():
                    return

                wait_handle.wait(sleep_interval_sec)
    except Exception:
        if error:
            error["error"] = sys.exc_info()
        raise
