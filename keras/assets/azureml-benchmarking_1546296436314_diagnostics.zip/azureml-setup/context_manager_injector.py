from __future__ import print_function

import argparse
import os
import runpy
import sys
import logging
import json

from contextlib import ExitStack


# For debugging purposes
# logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.INFO)

module_logger = logging.getLogger(__name__)
is_hdi = str(os.environ.get("AZUREML_TARGET_TYPE")) == "cluster"

if not is_hdi:
    from utility_context_managers import get_telemetry_client, EventTracker


class dummy():
    def __enter__(self):
        return None

    def __exit__(self, exc_type, exc_value, traceback):
        pass


class ContextManagerWrapper(object):
    def __init__(self, context_manager, name):
        self.context_manager = context_manager
        self.name = name

    def __enter__(self):
        module_logger.info("Entering context: " + self.name)
        self.context_manager.__enter__()

    def __exit__(self, *exc_details):
        module_logger.info("Exiting context: " + self.name)
        self.context_manager.__exit__(*exc_details)


def get_class(kls):
    """
    get class from fully qualified name
    https://stackoverflow.com/questions/452969/does-python-have-an-equivalent-to-java-class-forname
    """
    parts = kls.split('.')
    module = ".".join(parts[:-1])
    m = __import__(module)
    for comp in parts[1:]:
        m = getattr(m, comp)
    return m


def execute_with_context(wrapped_context_managers, invocation):
    primary_instance = not os.environ.get("AZUREML_SECONDARY_INSTANCE")
    try:
        telemetry_client = get_telemetry_client() if not is_hdi else None
        with EventTracker(telemetry_client, "ExitStack") if not is_hdi else dummy():
            with ExitStack() as stack:
                # Enter contexts
                for wrapper in wrapped_context_managers:
                    # Check if the context manager specified that it should only run on a single instance
                    single_instance = getattr(wrapper.context_manager, "single_instance", False)

                    if primary_instance or not single_instance:
                        with EventTracker(telemetry_client, "EnteringContext", {"contextName": wrapper.name}) if not \
                           is_hdi else dummy():
                            stack.enter_context(wrapper)

                # Run the user script
                expand_invocation = []
                for item in invocation:
                    item = os.path.expandvars(item)
                    expand_invocation.append(item)
                sys.argv = expand_invocation
                module_logger.debug("Executing script inside contexts: " + sys.argv[0])
                # Flush to get logging up to this point written to logs before logging from subprocess
                sys.stdout.flush()
                sys.stderr.flush()

                completion_message = "The experiment completed successfully."
                try:
                    with EventTracker(telemetry_client, "ExecutingScriptsInsideContexts") if not is_hdi else dummy():
                        runpy.run_path(sys.argv[0], globals(), run_name="__main__")
                except SystemExit as ex:
                    # Handle valid exit.  Raise exception for non-zero return code.
                    # TODO: Need to find out what caused the stack trace is printed
                    if ex.code is not None and ex.code != 0:
                        completion_message = "The experiment failed."
                        raise
                except BaseException:
                    completion_message = "The experiment failed."
                    raise
                finally:
                    # To indicate to a user that the user related command has
                    # completed,
                    # and now some post-processing steps will happen.
                    print("\n")
                    print(completion_message + " Finalizing run...")
                    # TODO: This is broken on worker nodes, so disabling for hdi.
                    # Disbaling for distributed runs as it's broken there too
                    if ((os.environ.get("AZUREML_PROCESS_NAME") is None or
                            os.environ.get("AZUREML_PROCESS_NAME") == "main") and
                            str(os.environ.get("AZUREML_TARGET_TYPE")) != "cluster"):
                        from log_history_status import log_finalizing
                        with EventTracker(telemetry_client, "FinalizingInRunHistory"):
                            log_finalizing()
    finally:
        if telemetry_client:
            telemetry_client.flush()


def create_wrapped_context_manager(pair):
    """
    attempt to import context manager type
    create context manager with its config
    and wrap it so that we can log enter and exit
    """

    cm_name, cm_type = pair.split(":")

    config_key = "AZUREML_CONTEXT_MANAGER_" + cm_name.upper()
    cm_config = os.environ.get(config_key)
    if cm_config:
        cm_config = json.loads(cm_config)

    # make class
    module_logger.debug("Importing context manager module for {0}".format(cm_name))
    cm_class = get_class(cm_type)

    # make object
    module_logger.debug("Constructing context manager object of type {0}".format(cm_class))
    context_manager = cm_class(cm_config)

    return ContextManagerWrapper(context_manager, cm_name)


if __name__ == '__main__':
    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument('-i', '--inject', action='append', default=[])
    argument_parser.add_argument("invocation", nargs=argparse.REMAINDER)
    options = argument_parser.parse_args()

    sys.path.append(os.path.dirname(__file__))

    cm_objects = [create_wrapped_context_manager(pair) for pair in options.inject]

    execute_with_context(cm_objects, options.invocation)
