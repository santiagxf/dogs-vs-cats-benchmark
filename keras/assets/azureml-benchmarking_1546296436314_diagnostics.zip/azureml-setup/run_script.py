# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from __future__ import print_function

import json
import os
import re
import subprocess
import sys
import time


try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError
except ImportError:
    from urllib2 import urlopen, Request, URLError

from threading import Event, Thread
from collections import namedtuple
from upload_artifacts import tail_upload_artifact
from execution_timer import ExecutionTimer
from spark_env_check import spark_environment_check

driver_log_timeout_envvar = 'AZUREML_DRIVERLOG_WAIT_TIMEOUT_SEC'
send_telemetry_timeout_envvar = 'AZUREML_TELEMETRY_TIMEOUT_SEC'
driver_log_timeout_sec = os.getenv(driver_log_timeout_envvar, 300)
send_telemetry_timeout_sec = os.getenv(send_telemetry_timeout_envvar, 60)
is_hdi = str(os.environ.get("AZUREML_TARGET_TYPE")) == "cluster"

if not is_hdi:
    from utility_context_managers import get_telemetry_client, DependencyTimer, TimeoutHandler, EventTracker


class dummy():
    def __enter__(self):
        return None

    def __exit__(self, exc_type, exc_value, traceback):
        pass


def merge_hdi_stdout(driver_log_path, yarn_app_id):
    from hdi_utilities import make_yarn_log_command

    if yarn_app_id is not None:
        try:
            with open(driver_log_path, "a+") as file:
                subprocess.check_call(make_yarn_log_command(yarn_app_id, "stderr"), stdout=file, stderr=file)
                subprocess.check_call(make_yarn_log_command(yarn_app_id, "stdout"), stdout=file, stderr=file)

        except Exception as exc:
            print(exc)
    else:
        print("Invalid YARN application ID")


def invoke():
    driver_log_path = os.environ.get("AZUREML_DRIVERLOG_PATH")
    cluster_run = (os.environ.get("AZUREML_TARGET_TYPE") == "cluster")

    start_time = time.time()

    return_code = None
    driver_log_wait_handle = None
    driver_log_uploader = None
    telemetry_client = get_telemetry_client() if not is_hdi else None
    try:
        # should UserProccess event only include the subprocess call?
        with EventTracker(telemetry_client, "UserProcess") if not is_hdi else dummy():
            with open(driver_log_path, "w") as file, ExecutionTimer("UserCode"):
                remote_driver_log_path = "azureml-logs/80_{}".format(os.path.basename(driver_log_path))
                driver_log_wait_handle = Event()
                driver_log_error = {"error": None}
                driver_log_uploader = Thread(
                    target=tail_upload_artifact,
                    args=(driver_log_path, remote_driver_log_path, driver_log_wait_handle, driver_log_error,))
                driver_log_uploader.daemon = True
                driver_log_uploader.start()

                command = sys.argv[1:]
                command[0] = os.path.expandvars(command[0])
                # Flush to get logging up to this point written to logs before logging from subprocess
                sys.stdout.flush()
                sys.stderr.flush()

                # Basic check of the Spark environment to display better error messages.
                spark_environment_check()

                # Make sure inheritable file descriptors are opened in child process
                # by explicitly setting close_fds=False
                subprocess.check_call(command, stdout=file, stderr=file, close_fds=False)
                return_code = 0
    except subprocess.CalledProcessError as ex:
        return_code = ex.returncode
        raise
    finally:
        try:
            print("Script process exited with code " + str(return_code))
            if driver_log_uploader is not None:
                if not os.environ.get("AZUREML_SECONDARY_INSTANCE"):
                    # Get HDI Stdout on the console
                    yarn_app_id = None
                    if cluster_run:
                        print("Collecting driver log from YARN...")
                        from hdi_utilities import get_yarn_app_id

                        with ExecutionTimer("MergingHdiOutput"):
                            yarn_app_id = get_yarn_app_id(driver_log_path)
                            # Note: It is important we merge this output *before*
                            # joining hte driver_log_uploader thread, othere wise
                            # we will not upload the entire log.
                            merge_hdi_stdout(driver_log_path, yarn_app_id)

                print("Uploading driver log...")
                failure_message = ""
                if (os.environ.get("AZUREML_TARGET_TYPE") == "batchai" or
                        os.environ.get("AZUREML_TARGET_TYPE") == "container"):
                    failure_message = "Full driver logs can be accessed in the file share directly."
                with DependencyTimer(name="DriverLogUpload", target=driver_log_path, message=failure_message,
                                     telemetry_client=telemetry_client) if not is_hdi else dummy():
                    with TimeoutHandler(operation_name="DriverLogUpload", timeout_sec=driver_log_timeout_sec,
                                        timeout_envvar=driver_log_timeout_envvar) if not is_hdi else dummy():
                        driver_log_wait_handle.set()
                        driver_log_uploader.join()
                        if driver_log_error["error"]:
                            error = driver_log_error["error"]
                            raise error[0].with_traceback(error[1], error[2])

            if not os.environ.get("AZUREML_SECONDARY_INSTANCE"):
                print("Finalizing run...")
                duration = time.time() - start_time
                with DependencyTimer(name="ResourceUsageTelemetry",
                                     suppress_logging=True, swallow_errors=True,
                                     telemetry_client=telemetry_client) if not is_hdi else dummy():
                    with TimeoutHandler(operation_name="ResourceUsageTelemetry",
                                        timeout_sec=send_telemetry_timeout_sec,
                                        timeout_envvar=send_telemetry_timeout_envvar) if not is_hdi else dummy():
                        send_telemetry(return_code, duration, yarn_app_id, telemetry_client)
        except Exception as ex:
            print(ex)
            raise
        finally:
            if telemetry_client:
                telemetry_client.flush()


Usage = namedtuple("Usage", ["cpu_cores", "memory_gb", "cpu_core_seconds", "memory_gb_seconds"])


def get_cpu_memory_usage():
    # Include virtual cores for consistency with YARN reporting.
    cpu_cores = get_cpu_cores()
    memory_gb = get_physical_memory()

    node_count = os.environ.get("AZUREML_NODE_COUNT")
    if node_count:
        node_count = int(node_count)
        if cpu_cores:
            cpu_cores *= node_count

        if memory_gb:
            memory_gb *= node_count

    if not cpu_cores:
        print("Warning: Unable to determine CPU cores information. Telemetry limited.")

    if not memory_gb:
        print("Warning: Unable to determine physical memory information. Telemetry limited.")

    return Usage(cpu_cores, memory_gb, None, None)


def get_cpu_cores():
    """
    :return: Returns logical cpu cores for windows and linux, if the command fails then
    it returns None
    :rtype: int
    """
    try:
        import multiprocessing
        return multiprocessing.cpu_count()
    except Exception:
        return None


def get_physical_memory():
    """
    :return: Returns physical memory on a machine in GB. Returns
    None if the command fails.
    """
    try:
        # posix works for linux and mac.
        if os.name == "posix":
            return get_physical_memory_linux()
        elif os.name == "nt":
            return get_physical_memory_windows()
        else:
            return None
    except Exception:
        return None


def get_physical_memory_windows():
    """
    :return: Returns physical memory on windows in GB or throws an
    exception if fails.
    :rtype: int
    """
    import ctypes

    class MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong),
            ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]

        def __init__(self):
            # have to initialize this to the size of MEMORYSTATUSEX
            self.dwLength = ctypes.sizeof(self)
            super(MEMORYSTATUSEX, self).__init__()

    stat = MEMORYSTATUSEX()
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
    return stat.ullTotalPhys / (1024 ** 3)


def get_physical_memory_linux():
    """
    :return: Returns physical memory on linux in GB or throws an
    exception if fails.
    :rtype: int
    """
    total_memory = os.popen("free -m").readlines()[1].split()[1]
    return int(total_memory) / (1024 ** 3)


def get_usage_from_yarn(yarn_app_id):
    cpu_cores = 0
    memory_gb = 0
    details = subprocess.check_output(["yarn", "node", "-list", "-all", "-showDetails"])
    details = str(details, "utf-8")
    for match in re.findall("Configured Resources : <memory:(\\d+), vCores:(\\d+)>", details):
        cpu_cores += int(match[1])
        memory_gb += int(match[0]) / 1024

    status = subprocess.check_output(["yarn", "application", "-status", yarn_app_id])
    status = str(status, "utf-8")
    match = re.search("Aggregate Resource Allocation : (\\d+) MB-seconds, (\\d+) vcore-seconds", status).groups()
    cpu_core_seconds = int(match[1])
    memory_gb_seconds = int(match[0]) / 1024

    return Usage(cpu_cores, memory_gb, cpu_core_seconds, memory_gb_seconds)


def send_telemetry(return_code, duration, yarn_app_id, telemetry_client):
    # TODO Need to add in the time the prepare operation took.
    if not telemetry_client:
        return

    vm_region = None
    vm_size = None
    try:
        request = Request("http://169.254.169.254/metadata/instance?api-version=2017-04-02")
        request.add_header("Metadata", "true")
        with urlopen(request) as response:
            raw = response.read()
            content = raw.decode(response.info().get_content_charset("utf-8"))
            metadata = json.loads(content)

            vm_size = metadata["compute"]["vmSize"]
            vm_region = metadata["compute"]["location"]
    except URLError as ex:
        bad_endpoint = False
        if isinstance(ex.reason, ConnectionRefusedError):
            bad_endpoint = True
        if isinstance(ex.reason, OSError):
            if ex.reason.errno == 10051:
                bad_endpoint = True

        if not bad_endpoint:
            print("Failed to retrieve VM information")
            print(ex)
    except Exception as ex:
        print(ex)

    if yarn_app_id:
        usage = get_usage_from_yarn(yarn_app_id)
    else:
        usage = get_cpu_memory_usage()

    cpu_cores, memory_gb, cpu_core_seconds, memory_gb_seconds = usage

    if not cpu_core_seconds and cpu_cores:
        cpu_core_seconds = cpu_cores * duration
    if not memory_gb_seconds and memory_gb:
        memory_gb_seconds = memory_gb * duration

    run_id = os.environ.get("AZUREML_RUN_ID")

    # Following dotnet telemetry standard naming convention for now.
    # TODO: Also fetch this from an environment variable.
    kubernetes_app = "execution-control"

    telemetry_client.track_trace(
        "Run ID {0} had return code {1} and actually used {2} CPU-core-seconds and {3} memory-GB-seconds".format(
            run_id, return_code, cpu_core_seconds, memory_gb_seconds),
        {
            "runId": run_id,
            "returnCode": return_code,
            "cpuCoreSeconds": cpu_core_seconds,
            "memoryGbSeconds": memory_gb_seconds,
            "cpuCores": cpu_cores,
            "memoryGbs": memory_gb,
            "duration": duration,
            "vmSize": vm_size,
            "vmRegion": vm_region,
            "subscription": os.environ.get("AZUREML_ARM_SUBSCRIPTION", ""),
            "workspaceName": os.environ.get("AZUREML_ARM_WORKSPACE_NAME", ""),
            "experimentName": os.environ.get("AZUREML_ARM_PROJECT_NAME", ""),
            "KubernetesApp": kubernetes_app
        })


if __name__ == "__main__":
    invoke()
