﻿# Simple Spark driver program that's run to cache Spark packages.

print("Spark packages cached!")
