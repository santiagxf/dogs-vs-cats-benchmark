from __future__ import print_function

import os
import sys


class dummy():
    def __enter__(self):
        return None

    def __exit__(self, exc_type, exc_value, traceback):
        pass


is_hdi = str(os.environ.get("AZUREML_TARGET_TYPE")) == "cluster"


class ProjectPythonPath(object):
    def __init__(self, config):
        self.single_instance = False

    def __enter__(self):
        project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        sys.path.append(project_dir)

    def __exit__(self, *args):
        pass


class RunHistory(object):
    def __init__(self, config):
        self.single_instance = True
        self.history_context = None
        self.timeout_envvar = 'AZUREML_OUTPUT_UPLOAD_TIMEOUT_SEC'
        self.exit_timeout_sec = os.getenv(self.timeout_envvar, 600)

    def __enter__(self):
        try:
            from azureml.history._tracking import get_history_context
        except ImportError:
            print("Warning: Unable to import azureml.history. Output collection disabled.")
            return

        # Until run history supports not sending status events, hack it out!
        # TODO Replace this with an actual configuration setting once it exists.
        def dont_send_status(self):
            pass

        from azureml.core.run import Run
        Run.start = dont_send_status
        Run.complete = dont_send_status
        Run.fail = dont_send_status

        # TODO Remove this logger and the param on get_history_context
        # Configure logging for azureml namepsace - debug logs+
        import logging
        aml_logger = logging.getLogger("azureml")

        # TODO remove callback param for history_context and delete nop
        def nop():
            pass

        blacklist = [os.environ.get("AZUREML_DRIVERLOG_PATH"), os.environ.get("AZUREML_CONTROLLOG_PATH")]
        if os.environ.get("AZUREML_DISTRIB_LOGS"):
            blacklist = os.environ.get("AZUREML_DISTRIB_LOGS").split(",")
        self.history_context = get_history_context(
            nop,
            sys.argv,
            aml_logger,
            [os.environ.get("AZUREML_LOGDIRECTORY_PATH")],
            blacklist)

        self.history_context.__enter__()

    def __exit__(self, *args):
        if not is_hdi:
            from utility_context_managers import DependencyTimer, TimeoutHandler
        failure_message = ""
        if (os.environ.get("AZUREML_TARGET_TYPE") == "batchai" or
                os.environ.get("AZUREML_TARGET_TYPE") == "container"):
            failure_message = "Output files can be accessed in the file share directly."
        with DependencyTimer(name="OutputUpload", message=failure_message) if not is_hdi else dummy():
            with TimeoutHandler(operation_name="OutputUpload", timeout_sec=self.exit_timeout_sec,
                                timeout_envvar=self.timeout_envvar) if not is_hdi else dummy():
                if self.history_context:
                    self.history_context.__exit__(*args)


class DaskOnBatch(object):
    def __init__(self, config):
        self.single_instance = True

    def __enter__(self):
        try:
            from azureml.contrib.daskonbatch import DaskHelper
            dh = DaskHelper()
            dh._preregister()
        except ImportError:
            pass

    def __exit__(self, *args):
        pass


class DataStores(object):
    def __init__(self, config):
        self.single_instance = True
        self.config = config
        self.timeout_envvar = 'AZUREML_DATASTORE_UPLOAD_TIMEOUT_SEC'
        self.exit_timeout_sec = os.getenv(self.timeout_envvar, 600)

    def __enter__(self):
        try:
            from azureml.data.context_managers import DatastoreContextManager
        except ImportError:
            print("Warning: Unable to import azureml.data. Download/Upload disabled.")
            return

        self.data_references = DatastoreContextManager(self.config)
        self.data_references.__enter__()

    def __exit__(self, *args):
        if not is_hdi:
            from utility_context_managers import DependencyTimer, TimeoutHandler
        # TODO: add actionable error message for the user in case of failure
        with DependencyTimer(name="DataStoreUpload") if not is_hdi else dummy():
            with TimeoutHandler(operation_name="DataStoreUpload", timeout_sec=self.exit_timeout_sec,
                                timeout_envvar=self.timeout_envvar) if not is_hdi else dummy():
                if self.data_references:
                    self.data_references.__exit__(*args)
