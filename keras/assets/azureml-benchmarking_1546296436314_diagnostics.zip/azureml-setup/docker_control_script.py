﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import argparse
import os
import subprocess
import sys

from execution_timer import ExecutionTimer
from threading import Event, Thread
from upload_artifacts import tail_upload_artifact
from log_history_status import log_preparing, log_running, log_completed, log_failed, log_canceled


import killable_subprocess
import interrupt_sender
import project_fetcher


run_id = os.environ["AZUREML_RUN_ID"]
pidfile_path = os.environ["AZUREML_PIDFILE_PATH"]
dockerfile_path = os.environ["AZUREML_DOCKERFILE_PATH"]
control_log_path = os.environ["AZUREML_CONTROLLOG_PATH"]

with open(pidfile_path, "a+") as file:
    file.write(str(os.getpid()))

control_log_wait_handle = None
control_log_uploader = None

try:
    success = False

    control_log_wait_handle = Event()
    control_log_uploader = Thread(
        target=tail_upload_artifact,
        args=(control_log_path, "azureml-logs/60_control_log.txt", control_log_wait_handle,))
    control_log_uploader.start()

    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument("--prepare", action="store_true", default=False)
    argument_parser.add_argument("--baseimage-address", default=None)
    argument_parser.add_argument("--baseimage-username", default=None)
    argument_parser.add_argument("--baseimage-password", default=None)
    argument_parser.add_argument("--build-image", action="store_true", default=False)
    argument_parser.add_argument("--shared-volumes", action="store_true", default=False)
    argument_parser.add_argument("--nvidia-docker", action="store_true", default=False)
    argument_parser.add_argument("--ports", default=None)
    argument_parser.add_argument("--tag", required=True)
    argument_parser.add_argument("--max-run-duration", default=None)
    argument_parser.add_argument("docker_invocation", nargs=argparse.REMAINDER)
    argument_parser.add_argument("--snapshot", default=None)
    options = argument_parser.parse_args()

    interrupt_sender.start(options.max_run_duration)

    docker = ["docker"]
    if sys.platform.startswith("linux"):
        docker = ["sudo"] + (["docker"] if not options.nvidia_docker else ["nvidia-docker"])

    def docker_execute_function(command_args, print_command_args=False, *popen_args, **kwargs):
        command_args = docker + command_args
        return killable_subprocess.check_call(command_args, *popen_args,
                                              print_command_args=print_command_args, **kwargs)

    def docker_error(error=None):
        if error:
            print(repr(error))

        print("Docker was not found on the target, check that it is installed and on the path.")
        sys.exit(1)

    def sudo_error(error=None):
        if error:
            print(repr(error))
        print('Unable to run docker with sudo. Check that sudo is configured to run docker without a password. '
              'See http://aka.ms/aml-ttysudoerror for more information.')
        sys.exit(1)

    # First, check if we can run docker at all.
    try:
        with open(os.devnull, 'w') as devnull:
            returncode = subprocess.call(["docker"], stdout=devnull, stderr=devnull)
            if returncode != 0:
                docker_error()
    except (subprocess.CalledProcessError, OSError, IOError) as error:
        docker_error(error)

    if sys.platform.startswith("linux"):
        # If we are on linux, check if we can run docker in sudo.
        # Error codes are not enough to distinguish between docker failing and sudo failing;
        # but if execution got here we can assume docker is installed.
        # So if this fails, it means we do not have passwordless access to run docker in sudo.
        try:
            with open(os.devnull, 'w') as devnull:
                returncode = subprocess.call(["sudo", "docker"], stdout=devnull, stderr=devnull)

                if returncode != 0:
                    sudo_error()

        except (subprocess.CalledProcessError, OSError) as error:
            sudo_error(error)

    if options.snapshot:
        project_fetcher.fetch_project_snapshot(options.snapshot)

    ports = []
    if options.ports:
        ports = options.ports.split(",")

    if options.baseimage_username and options.baseimage_password:
        if options.baseimage_address:
            login_command = [
                "login", "-u", options.baseimage_username,
                "-p", options.baseimage_password, options.baseimage_address]
        else:
            login_command = ["login", "-u", options.baseimage_username, "-p", options.baseimage_password]
        docker_execute_function(login_command)

    with ExecutionTimer("DockerInspect"):
        # Hide output from this inspection because it's not interesting for diagnostics
        # and will show an error in expected situations, which confuses log readers.
        # TODO: We do not use docker_execute_function, because we do not want its built in exception handling.
        #       We should eventually build a way to call it with more flexible error handling.
        with open(os.devnull, 'w') as devnull:
            return_code = subprocess.call(docker + ["inspect", options.tag], stdout=devnull, stderr=devnull)

    if return_code != 0:
        if not options.build_image:
            # If no need of building image, that indicates to directly download base image.
            pull_command = ["pull", options.tag]
            return_code = subprocess.call(docker + pull_command)
            if return_code != 0:
                print("Fail to pull down Docker image" +
                      " %s from image registry %s." % (options.tag, options.baseimage_address))
                print("Please check whether the image has been created in the image registry.")
                sys.exit(1)
        elif not options.prepare:
            print("A prepared Docker image was not found on the compute target.")
            print('You can prepare one explicitly by running \"az ml experiment prepare\" or you can turn on '
                  'automatic environment preparation by setting the PrepareEnvironment run configuration to true.')
            sys.exit(1)
        else:
            with ExecutionTimer("BuildDockerImage"):
                log_preparing()
                command = ["build", "-f", dockerfile_path, "-t", options.tag, "."]
                docker_execute_function(command, print_command_args=True)

    if not options.shared_volumes:
        print("Warning: The sharedVolumes setting in the compute target file is set to false. "
              "Setting it to true will provide better performance. For more details: "
              "https://aka.ms/azureml-sharedvolumes")
        print("")

    try:
        log_running()
        command = []
        if options.shared_volumes:
            command += ["run"]
        else:
            command += ["create"]

        command += ["--name", run_id]

        for port in ports:
            command += ["-p", port + ":" + port]

        if options.shared_volumes:
            command += ["--rm", "-v", os.getcwd() + ":/azureml-run"]

        # The docker invocation begins with a placeholder value to work with argparse.REMAINDER.
        command += options.docker_invocation[1:]

        def run_interrupted():
            with ExecutionTimer("DockerKill"):
                docker_execute_function(["kill", run_id])

        with ExecutionTimer("DockerRun"):
            try:
                if options.shared_volumes:
                    docker_execute_function(command, print_command_args=True, interrupt_handler=run_interrupted)
                else:
                    docker_execute_function(command, print_command_args=True)

                    copy = ["cp", "./.", run_id + ":/azureml-run/"]
                    docker_execute_function(copy, print_command_args=True)

                    start = ["start", "-a", run_id]
                    docker_execute_function(start, print_command_args=True, interrupt_handler=run_interrupted)
            except subprocess.CalledProcessError as ex:
                if ex.returncode == 125:
                    print("")
                    print("Failed to launch docker container.")
                    print("Check that docker is running and that C:\\ on Windows and /tmp elsewhere is shared.")
                    sys.exit(1)
                raise
    finally:
        if not options.shared_volumes:
            print("Extracting files from Docker container...")
            with ExecutionTimer("ExtractFiles"):
                docker_execute_function(["cp", run_id + ":/azureml-run/.", "."])

            print("Removing Docker container...")
            with ExecutionTimer("DockerRemove"):
                docker_execute_function(["rm", run_id])

        if options.baseimage_username and options.baseimage_password:
            print("Logging out of your docker container...")
            docker_execute_function(["logout"])
    success = True

except KeyboardInterrupt:
    print("Run interrupted by cancellation or because max duration exceeded.")
    log_canceled()
    sys.exit(1)
except subprocess.CalledProcessError as ex:
    # Don't print stack traces for failed subcommands -- they're useless.
    print(ex)
    sys.exit(1)
except Exception as ex:
    print(ex)
    raise
finally:
    sys.stdout.flush()
    sys.stderr.flush()
    if control_log_uploader is not None:
        print("Uploading control log...")
        control_log_wait_handle.set()
        control_log_uploader.join()

    print("Sending final run history status...")
    if success:
        log_completed()
    else:
        log_failed()

    ExecutionTimer.log_timers_to_file(ExecutionTimer.CONTROL_TIMER_LOG_PATH)
    os.remove(pidfile_path)

    print("Control script execution completed")
