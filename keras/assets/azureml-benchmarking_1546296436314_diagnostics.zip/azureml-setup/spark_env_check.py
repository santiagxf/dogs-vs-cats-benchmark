# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import os


# Function that conducts a basic check of the PySpark environment to display more informative error messages to users.
def spark_environment_check():
    # NOTE: Don't need to worry about lower/upper cases here as serialization/deserialization of json takes
    #       care of case-normalization and sets them to the right enums as defined in the services' contracts.
    if os.environ.get("AZUREML_FRAMEWORK") == "PySpark":
        if "SPARK_HOME" not in os.environ:
            raise RuntimeError("$SPARK_HOME is not set in the target environment. Please make sure PySpark "
                               "is installed correctly on the target environment.")

        spark_home = os.path.expandvars("$SPARK_HOME")
        spark_submit = os.path.join(spark_home, "bin/spark-submit")
        if not os.path.isfile(spark_submit):
            raise FileNotFoundError("Could not find: '{}'. Please make sure PySpark is installed correctly "
                                    "in: '{}' on the target environment.".format(spark_submit, spark_home))
