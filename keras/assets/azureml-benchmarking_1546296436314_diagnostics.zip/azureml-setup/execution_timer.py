""" Contains class for time execution. """
import time
import os


class TimerState():
    """Represent timer states."""
    NOT_STARTED = 0
    STARTED = 1
    STOPPED = 2
    ERROR = 4


class TimerStateException(Exception):
    """Exception thrown for invalid timer states."""

    def __init__(self, message):
        super(TimerStateException, self).__init__(message)


class ExecutionTimer(object):
    """ A time for measuring execution. It can be started once and stopped once. Execution Timers are not thread safe;
        we rely on there only being a single thread in control script/run script."""

    timers = []
    RUN_TIMER_LOG_PATH = "./azureml-logs/run_performance_timer_log.txt"
    CONTROL_TIMER_LOG_PATH = "./azureml-logs/control_performance_timer_log.txt"

    def __init__(self, name):
        self.name = name
        self.state = TimerState.NOT_STARTED
        self.start_time = 0.0
        self.end_time = 0.0
        ExecutionTimer.timers.append(self)

    def start(self):
        """ Start this timer. """
        if self.state is TimerState.NOT_STARTED:
            self.start_time = time.time()
            self.state = TimerState.STARTED
        else:
            old_state = self.state
            self.state = TimerState.ERROR
            raise TimerStateException("Tried to start timer that was in state: %s"
                                      % (str(old_state)))

    def stop(self):
        """ Stop this timer. """
        if self.state is TimerState.STARTED:
            self.state = TimerState.STOPPED
            self.end_time = time.time()
        else:
            old_state = self.state
            self.state = TimerState.ERROR
            raise TimerStateException("Tried to stop a timer that was in state: %s"
                                      % (str(old_state)))

    def get_elapsed_time(self):
        """Get the elapsed time recorded by this timer.
            Only valid to call after the timer has been stopped."""

        if self.state is TimerState.STOPPED:
            return self.end_time - self.start_time
        else:
            raise TimerStateException("Timer must be stopped before getting elapsed time."
                                      " Current state: %s"
                                      % (str(self.state)))

    @staticmethod
    def log_timers_to_file(log_file_path):
        def format_timer(timer):
            return "%s: %f seconds" % (timer.name, timer.get_elapsed_time())

        timer_string = os.linesep.join(map(format_timer, ExecutionTimer.timers))

        with open(log_file_path, "a+") as timer_log_file:
            timer_log_file.write(timer_string + os.linesep)

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, ty, value, traceback):
        pass
        self.stop()
