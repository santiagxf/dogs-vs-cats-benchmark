﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import argparse
import os
import subprocess
import sys
import time
import zipfile
import shutil
from threading import Event, Thread
import json


def _mpi_rank():
    value = os.environ.get("OMPI_COMM_WORLD_RANK")
    if value is None:
        value = os.environ.get("PMI_RANK")
    if value is None:
        return None
    return int(value)


def _mpi_world_size():
    value = os.environ.get("OMPI_COMM_WORLD_SIZE")
    if value is None:
        value = os.environ.get("PMI_SIZE")
    if value is None:
        return None
    return int(value)


def _is_ps_job():
    value = os.environ.get("PARAMETER_SERVER_JOB")
    if value is None:
        return False
    return bool(value)


def _ensure_directory_exists(directory):
    try:
        os.mkdir(directory)
    except Exception:
        # TODO Handle errors aside from the directory already existing.
        pass


class dummy():
    def __enter__(self):
        return None

    def __exit__(self, exc_type, exc_value, traceback):
        pass


def _create_archive(run_id):
    print("Creating diagnostic archive...")
    # The cwd here is the project directory, i.e., azureml/<project_dir>
    head, tail = os.path.split(os.getcwd())

    # Removing the original project zip.
    os.remove(os.path.join(head, run_id + ".zip"))

    # Creating the project zip with the current project directory, including the logs etc.
    # This will be used for diagnostics.

    # Archiving generates an exception due to missing upload_artifacts.cpython-36.pyc
    # at the time of archiving.
    # The issue is not major - the zip file is still created (but without upload_artifacts.cpython-36.pyc).
    # However, the exception causes the job to fail.
    # Swallowing exception for now until we understand why this happens and how to fix it.
    try:
        shutil.make_archive(os.path.join(head, run_id), "zip", os.path.join(head), run_id)
    except Exception as ex:
        print("make_archive threw exception: {}".format(ex))

    # TODO: Keeping the code for future use, in case we enable this functionality.
    # Moving out of the project directory to delete it.
    # os.chdir(head)
    # Removing the project directory after zipping it.
    # shutil.rmtree(os.path.join(head, run_id), ignore_errors=True)


run_id = os.environ["AZUREML_RUN_ID"]
log_directory_path = os.environ["AZUREML_LOGDIRECTORY_PATH"]
control_log_path = os.environ["AZUREML_CONTROLLOG_PATH"]
driver_log_path = os.environ["AZUREML_DRIVERLOG_PATH"]
control_log_str = control_log_path.replace("control_log", "control_log_{}_{}")
driver_log_str = driver_log_path.replace("driver_log", "driver_log_{}_{}")
control_log_timeout_envvar = 'AZUREML_CONTROLLOG_WAIT_TIMEOUT_SEC'
archiving_timeout_envvar = 'AZUREML_ARCHIVING_TIMEOUT_SEC'
control_log_timeout_sec = os.getenv(control_log_timeout_envvar, 300)
archiving_timeout_sec = os.getenv(archiving_timeout_envvar, 300)
is_hdi = str(os.environ.get("AZUREML_TARGET_TYPE")) == "cluster"

original_sys_argv = sys.argv

taskindex = ""
jobname = ""
psjob = _is_ps_job()
if psjob:
    tf_config = os.environ.get("TF_CONFIG")
    if not tf_config:
        message = "TF_CONFIG env variable (defined by Batch AI for parameter server jobs) is not found or empty."
        raise Exception(message)
    tf_config_json = json.loads(tf_config)
    print("TF_CONFIG:\n" + json.dumps(tf_config_json, indent=4))
    jobname = tf_config_json.get('task', {}).get('type')
    jobname = "worker" if jobname == "master" else jobname
    taskindex = tf_config_json.get('task', {}).get('index')

    if taskindex == 0 and jobname == "worker":
        cluster = tf_config_json.get('cluster')
        ps_spec = cluster.get('ps', {})
        worker_spec = cluster.get('worker', {})
        distrib_log_list = [control_log_str.format("ps", i) for i in range(len(ps_spec))]
        distrib_log_list += [driver_log_str.format("ps", i) for i in range(len(ps_spec))]
        distrib_log_list += [control_log_str.format("worker", i) for i in range(len(worker_spec))]
        distrib_log_list += [driver_log_str.format("worker", i) for i in range(len(worker_spec))]
        os.environ["AZUREML_DISTRIB_LOGS"] = ",".join(distrib_log_list)

argument_parser = argparse.ArgumentParser()
argument_parser.add_argument("--project-zip", required=True)
argument_parser.add_argument("--project-dir", required=True)
argument_parser.add_argument("invocation", nargs=argparse.REMAINDER)
argument_parser.add_argument("--snapshot", default=None)
options = argument_parser.parse_args()

_ensure_directory_exists(options.project_dir)
os.chdir(options.project_dir)
_ensure_directory_exists(log_directory_path)

rank = _mpi_rank()
# Non distributed: primary = true
# Distributed (MPI or Param Server): need a single primary instance.
# For MPI it's rank 0. For Parameter Server, it's worker 0.
distributed_job = rank is not None or psjob
primary_instance = (not distributed_job) or (rank == 0) or (taskindex == 0 and jobname == "worker")

rank_text = "main"
if distributed_job:
    if rank is not None:
        rank_text = "rank_{}".format(rank)
    else:  # psjob
        rank_text = "{}_{}".format(jobname, str(taskindex))

    # When running a distributed job, mangle our log filenames so we can put them side by side.
    # That way the user can easily see all of their control logs together.
    control_log_path = control_log_path.replace("control_log", "control_log_{}".format(rank_text))
    driver_log_path = driver_log_path.replace("driver_log", "driver_log_{}".format(rank_text))
    os.environ["AZUREML_DRIVERLOG_PATH"] = driver_log_path
    if not primary_instance:
        os.environ["AZUREML_SECONDARY_INSTANCE"] = "True"

    if rank == 0:
        world_size = _mpi_world_size()
        if world_size:
            distrib_log_list = [control_log_str.format("rank", i) for i in range(world_size)]
            distrib_log_list += [driver_log_str.format("rank", i) for i in range(world_size)]
            os.environ["AZUREML_DISTRIB_LOGS"] = ",".join(distrib_log_list)

os.environ["AZUREML_PROCESS_NAME"] = rank_text
print("AzureML logs can be found in the linked file share:")
print("azureml/" + run_id + "/azureml-logs")

control_log_wait_handle = None
control_log_uploader = None

with open(control_log_path, "w") as control_log:
    try:
        sys.stdout = control_log
        sys.stderr = control_log
        if psjob:
            print("This is a parameter server job. Job Name:{} Task index:{}.".format(jobname, str(taskindex)))
        elif rank is not None:
            print("This is an MPI job. Rank:{}".format(rank))

        success = False

        # Only extract the project on the primary instance.
        setup_path = os.path.abspath("azureml-setup")
        extraction_marker_path = os.path.join(setup_path, "extracted")

        setup_path_appended = False
        if primary_instance:
            with zipfile.ZipFile(options.project_zip, "r") as archive:
                archive.extractall(".")

            if options.snapshot:
                sys.path.append(setup_path)
                setup_path_appended = True
                import project_fetcher

                project_fetcher.fetch_project_snapshot(options.snapshot)

            os.mkdir(extraction_marker_path)

        # Non-primary instances should wait for the primary instance to
        # extract the project.
        while not os.path.exists(extraction_marker_path):
            time.sleep(0.01)

        if not setup_path_appended:
            sys.path.append(setup_path)

        from upload_artifacts import tail_upload_artifact

        remote_control_log_path = "azureml-logs/60_{}".format(os.path.basename(control_log_path))
        control_log_wait_handle = Event()
        control_log_error = {"error": None}
        control_log_uploader = Thread(target=tail_upload_artifact,
                                      args=(control_log_path,
                                            remote_control_log_path,
                                            control_log_wait_handle,
                                            control_log_error,))
        control_log_uploader.daemon = True
        control_log_uploader.start()

        share_directory = os.environ.get("AZUREML_NATIVE_SHARE_DIRECTORY")
        if share_directory:
            share_directory = os.path.expandvars(share_directory)
            os.environ["AZUREML_NATIVE_SHARE_DIRECTORY"] = share_directory
        # Flush to get logging up to this point written to logs before logging from subprocess
        sys.stdout.flush()
        sys.stderr.flush()

        # Make sure inheritable file descriptors are opened in child process
        # by explicitly setting close_fds=False
        subprocess.check_call(options.invocation, stdout=control_log, stderr=subprocess.STDOUT, close_fds=False)

        success = True

    except Exception as ex:
        print(ex)
        raise
    finally:
        telemetry_client = None
        try:
            # Technically, this is a lie. After all, we still have a little to do.
            # But tests expect this line to show up in the diagnostic zip, so we have to write it before
            # we actually zip it up.
            print("Control script execution completed")

            # For this reason, we also have to flush the buffer.
            control_log.flush()

            sys.stdout.flush()
            sys.stderr.flush()
            # Since we are stopping the log uploader, redirect to stdout/strerr
            # to avoid any subsequent logging missing from RunHistory
            sys.stdout = sys.__stdout__
            sys.stderr = sys.__stderr__

            if control_log_uploader is not None:
                print("Uploading control log...")
                if not is_hdi:
                    from utility_context_managers import get_telemetry_client, DependencyTimer, TimeoutHandler
                    telemetry_client = get_telemetry_client()
                failure_message = ""
                if (os.environ.get("AZUREML_TARGET_TYPE") == "batchai" or
                        os.environ.get("AZUREML_TARGET_TYPE") == "container"):
                    failure_message = "Full control logs can be accessed in the file share directly."
                with DependencyTimer(name="ControlLogUpload", target=control_log_path, message=failure_message,
                                     telemetry_client=telemetry_client) if not is_hdi else dummy():
                    with TimeoutHandler(operation_name="ControlLogUpload", timeout_sec=control_log_timeout_sec,
                                        timeout_envvar=control_log_timeout_envvar) if not is_hdi else dummy():
                        control_log_wait_handle.set()
                        control_log_uploader.join()
                        if control_log_error["error"]:
                            error = control_log_error["error"]
                            raise error[0].with_traceback(error[1], error[2])

            if primary_instance:
                from utility_context_managers import get_telemetry_client, DependencyTimer, TimeoutHandler
                failure_message = ""
                if (os.environ.get("AZUREML_TARGET_TYPE") == "batchai" or
                        os.environ.get("AZUREML_TARGET_TYPE") == "container"):
                    failure_message = "Diagnostic files can be accessed in the file share directly."
                with DependencyTimer(name="DiagnosticZipCreation", message=failure_message, swallow_errors=True,
                                     telemetry_client=telemetry_client) if not is_hdi else dummy():
                    with TimeoutHandler(operation_name="DiagnosticZipCreation", timeout_sec=archiving_timeout_sec,
                                        timeout_envvar=archiving_timeout_envvar) if not is_hdi else dummy():
                        _create_archive(run_id)
        except Exception as ex:
            print(ex)
            raise
        finally:
            if telemetry_client:
                telemetry_client.flush()
