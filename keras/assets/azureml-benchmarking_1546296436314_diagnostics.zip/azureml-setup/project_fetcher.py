﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from __future__ import print_function
from execution_timer import ExecutionTimer

import json
import os

try:
    # For Python 3.0 and later
    from urllib.request import urlopen, Request
except ImportError:
    # Fall back to Python 2's urllib2
    from urllib2 import urlopen, Request


def fetch_project_snapshot(snapshot_id):
    service_endpoint = os.environ["AZUREML_SERVICE_ENDPOINT"]
    account_token = os.environ["AZUREML_RUN_TOKEN"]
    subscription = os.environ["AZUREML_ARM_SUBSCRIPTION"]
    workspace = os.environ["AZUREML_ARM_WORKSPACE_NAME"]
    project = os.environ["AZUREML_ARM_PROJECT_NAME"]
    resource_group = os.environ["AZUREML_ARM_RESOURCEGROUP"]

    project_service_url = "%s/content/v1.0/subscriptions/%s/resourceGroups/%s"\
                          "/providers/Microsoft.MachineLearningServices/"\
                          "workspaces/%s/projects/%s/snapshots/%s/sas" %\
                          (service_endpoint, subscription, resource_group, workspace, project, snapshot_id)

    header = {"Authorization": "Bearer %s" % account_token}

    request = Request(project_service_url, headers=header)

    try:
        with ExecutionTimer("RetrieveProjectSasUrls"):
            response = urlopen(request)
    except Exception as ex:
        print("")
        print("Unable to retrieve SaS Urls for project downloand:")
        print(str(ex))
        exit(1)

    sas_tree = json.loads(_read_response(response))

    with ExecutionTimer("DownloadProjectFromSasUrls"):
        print("Starting project file download.")
        _download_tree(sas_tree, ["."])
        print("Finished project file download.")


def _read_response(response):
    response_content = response.read()

    # This is a hack to work around Python2/3 compatibility.
    # Reading a response in python2 gives a string; bytes is an alias for string in python2
    # In Python3, it produces an oject of type 'bytes' which is a distcint type from string
    # In that case we convert it to a string.
    if (type(response_content) is not str and type(response_content) is bytes):
        response_content = "".join(map(chr, response_content))

    return response_content


def _make_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)


def _is_file(node):
    return node["sasUrl"] is not None


def _download_tree(root, path_stack):
    if _is_file(root):
        full_path = "/".join(path_stack + [root["name"]])

        request = Request(root["sasUrl"])
        try:
            response = urlopen(request)
        except Exception as exception:
            print("")
            print("Unable to download project file: " + str(root["name"]))
            print(str(exception))
            exit(1)

        with open(full_path, "w+") as fh:
            fh.write(_read_response(response))

    else:
        if root["name"] != "":
            path_stack.append(root["name"])
        _make_directory("/".join(path_stack))

        for child in root["children"].values():
            _download_tree(child, path_stack)

        path_stack.pop()
