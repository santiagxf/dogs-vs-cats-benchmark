﻿from __future__ import print_function

import datetime
import os
import signal
import sys
import traceback
import time
import threading

#  We timeout a app insight telemetry call in 5 s
_TELEMETRY_CALL_TIMEOUT_IN_SEC = 5


def get_telemetry_client():
    """
    :return: Returns a timeout based app insight telemetry client or None
    :rtype: TimeoutBasedTelemetryClient
    """
    client = None
    key = os.environ.get("AZUREML_INSTRUMENTATION_KEY")
    is_hdi = str(os.environ.get("AZUREML_TARGET_TYPE")) == "cluster"
    # APP INSIGHTS currently turned off for HDI... TODO: turn it on for HDI
    if (key is not None) and not is_hdi:
        client = TimeoutBasedTelemetryClient(key)
    return client


def _timeout_decorator():
    def actual_decorator(test_function):
        """
        :param test_function:
        :type test_function: object
        :return: Returns the wrapper.
        :rtype: object
        """

        def wrapper(self, *args, **kwargs):
            """
            :param args:
            :type args: list
            :param kwargs:
            :type kwargs: dict
            :return: Returns the test function.
            :rtype: object
            """
            self_args_list = [self]
            if args:
                self_args_list = [self] + list(args)

            # Setting the thread to daemon, so that even if thread stays process exits.
            client_call_thread = threading.Thread(target=test_function, args=self_args_list, kwargs=kwargs,
                                                  name="AppInsightsTelemetryCall", daemon=True)

            client_call_thread.start()
            start_time = time.time()
            client_call_thread.join(timeout=_TELEMETRY_CALL_TIMEOUT_IN_SEC)
            if (time.time() - start_time) >= _TELEMETRY_CALL_TIMEOUT_IN_SEC:
                print("Warning: Logging to AppInsights taking more than {} s for {} function".format(
                    _TELEMETRY_CALL_TIMEOUT_IN_SEC, test_function.__name__))

        return wrapper
    return actual_decorator


# TODO: AppInsights python SDK is not supported, so we need to get rid of that.
# Timing out is only temporary solution.
class TimeoutBasedTelemetryClient(object):
    """
    A timeout based app insight telemetry client that timeouts all calls
    to the app insight telemetry client.
    We can't extend this class from applicationinsights.TelemetryClient
    as we don't know if appinsights will be available or not.
    """

    def __init__(self, appinsight_key):
        """
        :param appinsight_key:
        :type appinsight_key: str
        """
        self._appinsight_telemetry_client = None
        self._initialize_appinsight_telemetry_client(appinsight_key)

        if not self._appinsight_telemetry_client:
            print("Warning: Couldn't instantiate AppInsights telemetry client. Telemetry disabled.")

    @_timeout_decorator()
    def track_event(self, name, properties=None, measurements=None):
        """
        See applicationinsights.TelemetryClient.track_event
        """
        if self._appinsight_telemetry_client:
            self._appinsight_telemetry_client.track_event(name, properties=properties, measurements=measurements)

    @_timeout_decorator()
    def track_dependency(self, name, data, type=None, target=None, duration=None, success=None, result_code=None,
                         properties=None, measurements=None, dependency_id=None):
        """
        See applicationinsights.TelemetryClient.track_dependency
        """
        if self._appinsight_telemetry_client:
            self._appinsight_telemetry_client.track_dependency(
                name, data, type=type, target=target, duration=duration, success=success,
                result_code=result_code, properties=properties, measurements=measurements, dependency_id=dependency_id)

    @_timeout_decorator()
    def track_trace(self, name, properties=None, severity=None):
        """
        See applicationinsights.TelemetryClient.track_trace
        """
        if self._appinsight_telemetry_client:
            self._appinsight_telemetry_client.track_trace(name, properties=properties, severity=severity)

    @_timeout_decorator()
    def flush(self):
        """
        See applicationinsights.TelemetryClient.flush
        """
        if self._appinsight_telemetry_client:
            self._appinsight_telemetry_client.flush()

    @_timeout_decorator()
    def _initialize_appinsight_telemetry_client(self, appinsight_key):
        """
        :return: Returns application insights telemetry client or None if a
        application insights is not available or the call timeout.
        :rtype: applicationinsights.TelemetryClient
        """
        try:
            from applicationinsights import TelemetryClient
            if appinsight_key:
                self._appinsight_telemetry_client = TelemetryClient(appinsight_key)
        except Exception:
            pass


class DependencyTimer(object):
    def __init__(self, name, type="Finalization", target=None, message="",
                 suppress_logging=False, swallow_errors=False, telemetry_client=None,
                 exceptions_in_telemetry=False):
        self.name = name
        self.type = type
        self.target = target
        self.message = message
        self.suppress_logging = suppress_logging
        self.swallow_errors = swallow_errors
        self.telemetry_client = telemetry_client
        self.exceptions_in_telemetry = exceptions_in_telemetry

    def __enter__(self):
        self.start_time = datetime.datetime.now()
        return self

    def __exit__(self, exc_type, exc_val, tb):
        try:
            duration = datetime.datetime.now() - self.start_time
            duration_ms = duration.total_seconds() * 1000
            success = exc_val is None or (exc_type == SystemExit and (exc_val.code is None or exc_val.code == 0))
            if not success:
                if not self.suppress_logging:
                    from log_history_status import log_warning
                    target_msg = " to {}".format(self.target) if self.target else ""
                    error_message = "{}: {} {} failed. {}. Exception Details:{}".format(
                        "WARNING" if self.swallow_errors else "ERROR:",
                        self.name, target_msg, self.message,
                        "".join(traceback.format_exception(exc_type, exc_val, tb)))
                    if self.swallow_errors:
                        log_warning(error_message)
                    else:
                        # TODO: change this to log_error once RunHistory supports multiple errors
                        # log_error(error_message)
                        log_warning(error_message)
            log_telemetry = os.environ.get("AZURE_CORE_COLLECT_TELEMETRY")
            if (log_telemetry is None or (log_telemetry.lower() != "no" and log_telemetry.lower() != "false")):
                client = get_telemetry_client() if not self.telemetry_client else self.telemetry_client
                run_id = os.environ.get("AZUREML_RUN_ID")
                properties = {"runId": run_id,
                              "exception": "".join(traceback.format_exception_only(exc_type, exc_val))
                              if not success and self.exceptions_in_telemetry else ""}
                client.track_dependency(self.name, None, self.type, self.target,
                                        duration_ms, success, properties=properties)
                if not self.telemetry_client:
                    client.flush()
        except Exception as ex:
            print("Exception in DependencyTimer __Exit__ {}".format(ex))
        if self.swallow_errors:
            return True


# The timeout fires in POSIX compliant OS
class TimeoutHandler(object):
    def __init__(self, operation_name, timeout_sec, timeout_envvar=None):
        self.timeout_sec = timeout_sec
        self.operation_name = operation_name
        self.posix = os.name == "posix"
        self.timeout_envvar = timeout_envvar

    def _raise_timeout_error(self, signum, frame):
        action_message = ""
        if self.timeout_envvar:
            action_message = "The timeout can be adjusted using {} environment variable".format(self.timeout_envvar)
        sys.exit("Operation {} timed out after {} sec. {}".format(self.operation_name,
                                                                  self.timeout_sec,
                                                                  action_message))

    def __enter__(self):
        if self.posix:
            signal.signal(signal.SIGALRM, self._raise_timeout_error)
            signal.alarm(self.timeout_sec)

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.posix:
            signal.alarm(0)


class EventTracker(object):
    def __init__(self, telemetry_client, event_name, custom_properties=None, log_exceptions=False):
        self.client = telemetry_client
        self.event_name = event_name
        self.custom_properties = custom_properties
        self.start_time = None
        self.process_name = os.environ.get("AZUREML_PROCESS_NAME")
        self.log_exceptions = log_exceptions

    def __enter__(self):
        if self.client:
            self.start_time = time.time()

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            end_time = time.time()
            success = exc_val is None or (exc_type == SystemExit and (exc_val.code is None or exc_val.code == 0))
            properties = {"start": self.start_time,
                          "end": end_time,
                          "duration": end_time - self.start_time,
                          "runId": os.environ.get("AZUREML_RUN_ID"),
                          "status": "Passed" if success else "Failed",
                          "exception": "".join(traceback.format_exception_only(exc_type, exc_val))
                          if not success and self.log_exceptions else "",
                          "process": self.process_name, }
            if self.custom_properties:
                properties.update(self.custom_properties)
            self.client.track_event(self.event_name, properties)
