﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from __future__ import print_function

import os
import sys
import time


class CondaLock(object):
    def __init__(self):
        # AZUREML_CONDA_LOCK_PATH contains env vars such as $HOME or $USERPROFILE so we need to expand the
        # environment variables here in order to prevent having env vars used as string literals in the path.
        self._path = os.path.expandvars(os.environ["AZUREML_CONDA_LOCK_PATH"])

    def __enter__(self):
        while True:
            try:
                os.makedirs(self._path)
                break
            except OSError:
                pass

            print("Waiting for other Conda operations to finish...")
            print("Delete " + self._path + " to override.")
            print("")
            sys.stdout.flush()
            time.sleep(1)

    def __exit__(self, type, value, traceback):
        os.rmdir(self._path)
