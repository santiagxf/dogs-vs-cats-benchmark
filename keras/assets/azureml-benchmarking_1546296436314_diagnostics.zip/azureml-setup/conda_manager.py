# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import os
import subprocess
import sys

import killable_subprocess

from conda_lock import CondaLock
from execution_timer import ExecutionTimer
from log_history_status import log_preparing


def remove_partial_conda_environment(environment_path, conda, sudo):
    remove = _sudo_command_helper([conda, "env", "remove", "-p", environment_path], sudo)
    killable_subprocess.check_call(remove)


def _sudo_command_helper(command, sudo):
    if sudo:
        command = ["sudo"] + command
    return command


# NOTE: There's a bug in conda where it doesn't respect the append operation for configs and if new values are added,
# newly appended values are actually prepended before conda default values as the default values are compiled
# after retrieving the user set values in conda config.
# Hence, we retrieve the current envs_dirs, check if there are any user-set values and if there are, append our
# AzureML conda envs directory to conda config as the default conda envs dir is already set to a non-default dir
# and will not alter the user's expected behavior for conda envs dirs. If not, we first retrieve the compiled values
# for envs_dirs (including the conda default envs dirs), append to the list, then set the envs_dirs to not modify the
# user's expected behavior for conda envs dirs (conda default envs_dirs will remain as the default dir for conda envs).
def append_envs_dirs_to_conda_config(envs_dir, conda, sudo):
    expanded_aml_envs_dir = os.path.expandvars(envs_dir)

    get_envs_dirs_cmd = _sudo_command_helper([conda, "config", "--get", "envs_dirs"], sudo)
    user_set_envs_dirs = subprocess.check_output(get_envs_dirs_cmd, encoding="utf-8")

    if user_set_envs_dirs:
        # using normpath on an empty string changes it to ".", so calling normpath after checking for an empty string.
        user_set_envs_dirs = os.path.normpath(user_set_envs_dirs)
        if (envs_dir in user_set_envs_dirs) or (expanded_aml_envs_dir in user_set_envs_dirs):
            return

        print("")
        print("Found the following user-set conda config values for envs_dirs:")
        print("")
        print(user_set_envs_dirs)
        print("Appending AzureML conda envs directory: {} to the envs_dirs listed above.".format(envs_dir))
        print("")
        append_envs_dirs_cmd = _sudo_command_helper([conda, "config", "--append", "envs_dirs", envs_dir], sudo)
        subprocess.check_call(append_envs_dirs_cmd)
    else:
        show_envs_dirs_cmd = _sudo_command_helper([conda, "config", "--show", "envs_dirs"], sudo)
        current_envs_dirs = subprocess.check_output(show_envs_dirs_cmd, encoding="utf-8")
        # "conda config --show" always returns the absolute path (w/o env vars), so checking against the expanded path.
        if expanded_aml_envs_dir not in current_envs_dirs:
            print("")
            print("Found the following conda default values for envs_dirs:")
            print("")
            print(current_envs_dirs)
            print("Appending AzureML conda envs directory: {} to the default envs_dirs listed above.".format(envs_dir))
            print("")
            envs_dirs_to_add = current_envs_dirs + '  - {}'.format(envs_dir)
            set_envs_dirs_cmd = _sudo_command_helper([conda, "config", "--stdin"], sudo)
            subprocess.check_output(set_envs_dirs_cmd, input=envs_dirs_to_add.encode())


# Note: Just checking for the existence of environment_indicator and environment_path directory,
# and not the validity of environment_path's contents.
# The reason is that if environment_indicator is present, then we believe that environment_path directory
# was generated correctly. Right now, we are only handling the case that environment_path directory
# was deleted somehow. But if users are messing up with the contents of environment_path directory then
# that is not yet handled.
def prepare_conda_or_error(manage_environment, prepare_environment, conda="conda", sudo=False, zip=False):
    if manage_environment:
        environment_path = os.environ["AZUREML_CONDA_ENVIRONMENT_PATH"]
        environment_path = os.path.expandvars(environment_path)

        environment_indicator = os.environ["AZUREML_CONDA_ENVIRONMENT_EXISTENCE_INDICATOR"]
        environment_indicator = os.path.expandvars(environment_indicator)

        environment_exists = os.path.exists(environment_indicator) and os.path.exists(environment_path)

        if not environment_exists:
            if not prepare_environment:
                print("A prepared conda environment was not found on the compute target.")
                print('You can prepare one explicitly by running'
                      ' \"az ml experiment prepare\" or you can turn'
                      ' on automatic environment preparation by setting the PrepareEnvironment'
                      ' run configuration to true.')
                sys.exit(1)
            else:
                prepare_conda_environment(environment_indicator, environment_path, conda, sudo, zip)


def prepare_conda_environment(environment_indicator, environment_path, conda, sudo, zip):
    conda_command = _sudo_command_helper([conda], sudo)

    with CondaLock():
        try:
            version_command = conda_command + ["--version"]
            print("Running " + str(version_command))
            conda_version_output = subprocess.check_output(
                version_command, stderr=subprocess.STDOUT)
            conda_version = conda_version_output.decode("UTF-8").replace("conda", "").strip()
        except Exception as ex:
            print(ex)
            print("")
            print("Unable to run the Conda package manager. AzureML uses Conda to provision python")
            print("environments from a dependency specification. To manage the python environment")
            print("manually instead, set userManagedDependencies to True in the python environment")
            print("configuration. To use system managed python environments, install Conda from:")
            print("https://conda.io/miniconda.html")
            sys.exit(1)

        from distutils.version import LooseVersion
        installed_version = LooseVersion(conda_version)
        required_version = LooseVersion("4.4.0")
        if installed_version < required_version:
            print("AzureML requires Conda version {} or later.".format(required_version))
            print("You can install this by running:")
            print("{} update conda".format(" ".join(conda_command)))
            print("")
            sys.exit(1)

        if not (os.path.exists(environment_indicator) and os.path.exists(environment_path)):
            # Removing the indicator before preparing the conda environment if it exists.
            if os.path.exists(environment_indicator):
                import shutil
                shutil.rmtree(environment_indicator)

            print("Creating Conda environment...")
            with ExecutionTimer("CreateCondaEnvironment"):
                log_preparing()

                create = [
                    "env", "create",
                    "-p", environment_path,
                    "-f", "azureml-setup/mutated_conda_dependencies.yml"]
                killable_subprocess.subprocess_with_failure_recovery(
                    conda_command + create,
                    lambda args, error: remove_partial_conda_environment(environment_path, conda, sudo))

                if zip:
                    compress = _sudo_command_helper(["zip", "-r", environment_path + ".zip", environment_path], sudo)
                    killable_subprocess.check_call(compress)

                # Adding AzureML managed conda envs directory to the user's conda config to make sure that the env
                # created by a system managed run can be addressed using its name instead of the full path.
                try:
                    aml_conda_dir = os.path.normpath(os.path.join(os.environ["AZUREML_USER_CONDA_DIRECTORY"], "envs"))
                    append_envs_dirs_to_conda_config(aml_conda_dir, conda, sudo)
                except Exception as ex:
                    print(ex)
                    print("")
                    print("Encountered an error while trying to add the AzureML managed conda environment "
                          "directory to the user's conda configuration.")
                    print("You can manually add the AzureML managed conda environment directory "
                          "to your conda config by running:")
                    print("{}conda config --append envs_dirs {}".format("sudo " if sudo else "", aml_conda_dir))
                    print("")
                    print("Or by manually editing the .condarc file located in your home directory "
                          "and adding the following:")
                    print("envs_dirs:")
                    print("  - {}".format(aml_conda_dir))
                    print("")

                os.makedirs(environment_indicator)
