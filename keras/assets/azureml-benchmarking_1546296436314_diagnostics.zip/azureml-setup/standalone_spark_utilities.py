﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import os


def get_master_ip():
    master_ip_str = os.environ.get('AZ_BATCH_MASTER_NODE')
    if not master_ip_str:
        raise ValueError('Failed to get azure batch cluster master node IP address from BatchAI.')
    master_ip_pair = master_ip_str.split(':')
    if len(master_ip_pair) != 2:
        raise ValueError('Invalid azure batch master node IP address and port number.')
    return master_ip_pair[0]


def is_primary_instance():
    is_secondary_instance = os.environ.get('AZUREML_SECONDARY_INSTANCE')
    return is_secondary_instance != "True"


def get_spark_home():
    spark_home = os.environ.get('SPARK_HOME')
    if not spark_home:
        raise ValueError('Environment variable SPARK_HOME is not defined in docker image.')
    return spark_home
