﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import os
import datetime
import json

try:
    # For Python 3.0 and later
    from urllib.request import urlopen, Request, HTTPError
except ImportError:
    # Fall back to Python 2's urllib2
    from urllib2 import urlopen, Request, HTTPError


def try_request(request, method=None):
    try:
        if method:
            request.method = method
        urlopen(request)
    except HTTPError as ex:
        print(ex.code)
        print(ex.read())


def log_status(status, message=None):
    run_id = os.environ["AZUREML_RUN_ID"]
    service_endpoint = os.environ["AZUREML_SERVICE_ENDPOINT"]
    arm_scope = os.environ.get("AZUREML_EXPERIMENT_SCOPE")
    account_token = os.environ.get("AZUREML_RUN_TOKEN")

    history_url = service_endpoint + "/history/v1.0" + arm_scope + "/runs/" + run_id + "/"
    events_url = history_url + "events"

    payload = {
        "Name": "Microsoft.MachineLearning.Run." + status,
        "Data": {
            "RunId": "{0}".format(run_id)
        }
    }

    if status == "Start" or status == "Preparing":
        payload["Data"]["StartTime"] = "{0}".format(datetime.datetime.utcnow().isoformat())
    elif status == "Completed" or status == "Failed" or status == "Canceled":
        payload["Data"]["EndTime"] = "{0}".format(datetime.datetime.utcnow().isoformat())
    elif status == "Warning" and message:
        payload["Data"]["Message"] = "{0}".format(message)
    elif status == "Error" and message:
        payload["Data"]["ErrorResponse"] = {"Error": {"Message": "{}".format(message)}}

    json_data = json.dumps(payload).encode('utf8')
    request = Request(events_url, data=json_data, headers={
                        "Authorization": "Bearer {0}".format(account_token), 'Content-Type': 'application/json'})
    try_request(request)


def log_preparing():
    print("Logging experiment preparation status in history service.")
    log_status("Preparing")


def log_running():
    print("Logging experiment running status in history service.")
    log_status("Start")


def log_finalizing():
    print("Logging experiment finalizing status in history service")
    log_status("Finalizing")


def log_completed():
    print("Logging experiment completed status in history service.")
    log_status("Completed")


def log_failed():
    print("Logging experiment failed status in history service.")
    log_status("Failed")


def log_canceled():
    print("Logging experiment canceled status in history service.")
    log_status("Canceled")


def log_warning(warning_message):
    print("Logging warning in history service:{}".format(warning_message))
    log_status("Warning", warning_message)


def log_error(error_message):
    print("Logging error in history service:{}".format(error_message))
    log_status("Error", error_message)
