from __future__ import print_function

import os
import time

from datetime import datetime

from threading import Thread

# TODO Find a more python way of performing this travesty.
try:
    import thread as _thread
except Exception:
    import _thread


def _watch(max_run_duration=None):
    path = os.path.join(os.path.dirname(__file__), "killfile")
    start_time = datetime.now()
    while True:
        time.sleep(0.25)
        current_time = datetime.now() - start_time

        if max_run_duration is not None and current_time.total_seconds() > float(max_run_duration):
            print("Max run duration of {} seconds elapsed. "
                  "-- interrupting main to kill the experiment!".format(max_run_duration))
            _thread.interrupt_main()
            return

        if os.path.isfile(path):
            print("Killfile detected -- interrupting main!")
            _thread.interrupt_main()
            return


# Also adding a max run duration check in this file. So, now this file checks if there is a kill file
# or the max duration time has elapsed. The reason to add the max duration check along with the kill file check
# is to have only one thread that interrupts the main thread, and we don't ever go in the case of the main thread
# receiving two or more interrupts, in that case there could be dual cleanup or error in performing
# cleanup multiple times.
def start(max_run_duration=None):
    watcher = Thread(target=_watch, args=(max_run_duration,))
    watcher.daemon = True
    watcher.start()
