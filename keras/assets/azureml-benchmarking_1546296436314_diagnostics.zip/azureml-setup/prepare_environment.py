﻿# Simple program to set up environment.

print("")
print("")
print("Hello!")
print("Your environment is now ready.")
print("")
print("")
